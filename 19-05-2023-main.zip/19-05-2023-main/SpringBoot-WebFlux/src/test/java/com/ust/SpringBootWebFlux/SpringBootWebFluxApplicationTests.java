package com.ust.SpringBootWebFlux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebFluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
